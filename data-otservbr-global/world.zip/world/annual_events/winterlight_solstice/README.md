# Annual Events - Winterlight Solstice

During this event, it is possible to challenge [The Percht Queen](https://www.tibiawiki.com.br/wiki/The_Percht_Queen).


__References__:
- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Winterlight_Solstice)

## Map

The included map adds [The Percht Queen's Island](https://www.tibiawiki.com.br/wiki/The_Percht_Queen%27s_Island)

### General Position 
[33768,31051,7](https://tibiamaps.io/map#33768,31051,7:1)

### Notes

Share the same map position as the [Orcsoberfest Island](https://www.tibiawiki.com.br/wiki/Orcsoberfest_Island).
