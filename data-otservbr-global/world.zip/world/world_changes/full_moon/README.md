# World Change - Full Moon

During this World Change that usually happens between 12, 13 and 14 of each month it is possible to challenge the Boss Feroxa during the Grimvale quest.


During the boss fight, the arena will change as the battle progress.

![fexore map](https://user-images.githubusercontent.com/16576236/183953891-3b298de6-fcca-46b6-9ee0-e8df1c216a2e.gif)

__References__:

- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Mini_World_Changes#Full_Moon)

### General Position 
`33919,31047,8`