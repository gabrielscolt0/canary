# World Change (Mini) - Nightmare Isles

A random portal to [Nightmare Isles](https://www.tibiawiki.com.br/wiki/Nightmare_Isles) will spawn randomly in three locations.

__References__:

- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Mini_World_Changes#Nightmare_Isles)

## Ankrahmun (North)

### General Position 
[33254,32677,7](https://tibiamaps.io/map#33254,32677,7:1)

## Darashia (North)

### General Position 
[33219,32276,7](https://tibiamaps.io/map#33219,32276,7:1)

## Darashia (West)

### General Position 
[33029,32404,7](https://tibiamaps.io/map#33029,32404,7:1)
