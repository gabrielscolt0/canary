# World Change (Mini) - Fury Gates

A random portal to [Fury Hell](https://www.tibiawiki.com.br/wiki/Fury_Hell) will spawn randomly in a various number of locations.

__References__:

- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Mini_World_Changes#Fury_Gates)

## Carlin

### General Position 
[32261,31848,7](https://tibiamaps.io/map#32261,31848,7:1)

## Ab'Dendriel

### General Position 
[32680,31721,7](https://tibiamaps.io/map#32680,31721,7:1)

## Kazordoon

### General Position 
[32573,31981,7](https://tibiamaps.io/map#32573,31981,7:1)

## Thais

### General Position 
[32266,32164,7](https://tibiamaps.io/map#32266,32164,7:1)

## Venore

### General Position 
[32833,32083,7](https://tibiamaps.io/map#32833,32083,7:1)

## Edron

### General Position 
[33220,31921,7](https://tibiamaps.io/map#33220,31921,7:1)

## Darashia

### General Position 
[33300,32371,7](https://tibiamaps.io/map#33300,32371,7:1)

## Ankrahmun

### General Position 
[33267,32841,7](https://tibiamaps.io/map#33267,32841,7:1)

## Port Hope

### General Position 
[32530,32716,7](https://tibiamaps.io/map#32530,32716,7:1)

## Liberty Bay

### General Position 
[32348,32695,7](https://tibiamaps.io/map#32348,32695,7:1)