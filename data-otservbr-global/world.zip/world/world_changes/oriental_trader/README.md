# World Change (Mini) - Oriental Trader

The NPC [Yasir](https://www.tibiawiki.com.br/wiki/Yasir), during this mini-world change Yasir can appear at different places.

__References__:

- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Mini_World_Changes#Fury_Gates)

## Carlin

### General Position 
[32400,31815,6](https://tibiamaps.io/map#32400,31815,6:1)

## Libery Bay

### General Position 
[32314,32895,6](https://tibiamaps.io/map#32314,32895,6:1)

## Ankrahmun

### General Position 
[33102,32884,6](https://tibiamaps.io/map#33768,31051,7:1)