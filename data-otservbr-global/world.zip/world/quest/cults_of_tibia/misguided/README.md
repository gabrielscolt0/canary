
# Cults of Tibia Quest - The Misguided

In the Cults of Tibia Quest in The Misguided Cult, their hunting ground is deceptive showing richness all around as the quest progress the player can see what is the true reality.


__References__:

- [Tibia Wiki](https://www.tibiawiki.com.br/wiki/Cults_of_Tibia_(The_Misguided))

## Illusion

The hunting ground is beautiful with marble walls and gold around the floor.

### General Position 
[32541,32350,10](https://tibiamaps.io/map#32541,32350,10:2)

## Reality

The illusion is gone, the hunting ground is dirt with multiple leaves, dirt ground and walls made of wood.

### General Position 
[32541,32350,10](https://tibiamaps.io/map#32541,32350,10:2)