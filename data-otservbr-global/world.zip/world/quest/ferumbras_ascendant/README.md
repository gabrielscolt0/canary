# Ferumbras Ascendant Quest

# Zamulosh Puzzle Habitats
Used to reset to their original view after being corrupted during the puzzle.

### General Position
[33624,32692,12](https://tibiamaps.io/map#33624,32692,12:2)